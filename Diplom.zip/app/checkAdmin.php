<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class checkAdmin extends Model
{
    //
}
